/*
canva.js - Helper functions for interacting with Canva API.
Note: Canva API endpoints/fields may change. Adjust according to Canva docs.
*/
const axios = require('axios');
const qs = require('querystring');

const CANVA_OAUTH_TOKEN_URL = 'https://www.canva.com/oauth/token';
const CANVA_API_BASE = 'https://api.canva.com/v1';

async function exchangeAuthCodeForToken(code, clientId, clientSecret, redirectUri) {
  const body = {
    grant_type: 'authorization_code',
    code,
    client_id: clientId,
    client_secret: clientSecret,
    redirect_uri: redirectUri
  };
  const res = await axios.post(CANVA_OAUTH_TOKEN_URL, qs.stringify(body), {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  });
  return res.data;
}

async function refreshCanvaToken(refreshToken, clientId, clientSecret) {
  const body = {
    grant_type: 'refresh_token',
    refresh_token: refreshToken,
    client_id: clientId,
    client_secret: clientSecret
  };
  const res = await axios.post(CANVA_OAUTH_TOKEN_URL, qs.stringify(body), {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  });
  return res.data;
}

async function createDesignFromTemplate(accessToken, templateId, variables = {}) {
  // Payload may require a different schema depending on Canva API version.
  const payload = {
    template_id: templateId,
    variables
  };
  const res = await axios.post(`${CANVA_API_BASE}/designs`, payload, {
    headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' }
  });
  return res.data;
}

async function exportDesignImage(accessToken, designId, options = { format: 'png', width: 1024 }) {
  const payload = {
    format: options.format || 'png',
    width: options.width || 1024
  };
  const res = await axios.post(`${CANVA_API_BASE}/designs/${designId}/exports`, payload, {
    headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' }
  });
  return res.data;
}

module.exports = {
  exchangeAuthCodeForToken,
  refreshCanvaToken,
  createDesignFromTemplate,
  exportDesignImage
};
