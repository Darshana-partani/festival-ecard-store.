/*
Festival E-Card Store - Backend (Integrated)
Components:
- WhatsApp Cloud webhook (Meta)
- OpenAI integration for conversation
- Canva integration helper (calls canva.js)
- S3 upload helper (calls s3-utils.js)
- Razorpay webhook placeholder
- MongoDB orders storage (mongoose)
Note: Fill .env with actual credentials.
*/
const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');
const canva = require('./canva');
const s3utils = require('./s3-utils');
const Razorpay = require('razorpay');
const crypto = require('crypto');
const OpenAI = require('openai');

dotenv.config();
const app = express();
app.use(bodyParser.json());

// Env
const PORT = process.env.PORT || 5000;
const {
  MONGODB_URI,
  WHATSAPP_PHONE_NUMBER_ID,
  WHATSAPP_ACCESS_TOKEN,
  WHATSAPP_VERIFY_TOKEN,
  OPENAI_API_KEY,
  RAZORPAY_KEY_ID,
  RAZORPAY_KEY_SECRET,
  RAZORPAY_WEBHOOK_SECRET,
  CANVA_ACCESS_TOKEN,
  CANVA_TEMPLATE_1_ID,
  CANVA_TEMPLATE_2_ID,
  CANVA_TEMPLATE_3_ID,
  SERVER_URL
} = process.env;

if (!MONGODB_URI) console.warn('MONGODB_URI not set in .env');

// Connect MongoDB
mongoose.connect(MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true }).catch(err => {
  console.error('Mongo connection error:', err.message);
});

// Order model
const orderSchema = new mongoose.Schema({
  whatsapp: String,
  festival: String,
  name: String,
  message: String,
  templateChoice: String,
  status: String,
  preview_s3_key: String,
  final_s3_key: String,
  design_id: String,
  razorpay_link_id: String,
  razorpay_short_url: String,
  createdAt: { type: Date, default: Date.now },
  updatedAt: Date
});
const Order = mongoose.model('Order', orderSchema);

// OpenAI client
const openai = new OpenAI.OpenAIApi(new OpenAI.Configuration({ apiKey: OPENAI_API_KEY }));

// Razorpay client
const razorpay = new Razorpay({ key_id: RAZORPAY_KEY_ID, key_secret: RAZORPAY_KEY_SECRET });

// -------------------- WhatsApp helpers (Meta Cloud) --------------------
async function sendWhatsAppText(to, text) {
  const url = `https://graph.facebook.com/v17.0/${WHATSAPP_PHONE_NUMBER_ID}/messages`;
  try {
    const payload = {
      messaging_product: 'whatsapp',
      to: to.replace('whatsapp:', ''),
      text: { body: text }
    };
    const res = await axios.post(url, payload, {
      headers: { Authorization: `Bearer ${WHATSAPP_ACCESS_TOKEN}`, 'Content-Type': 'application/json' }
    });
    return res.data;
  } catch (err) {
    console.error('sendWhatsAppText error', err?.response?.data || err.message);
    throw err;
  }
}

async function sendWhatsAppImage(to, imageUrl, caption='') {
  const url = `https://graph.facebook.com/v17.0/${WHATSAPP_PHONE_NUMBER_ID}/messages`;
  try {
    const payload = {
      messaging_product: 'whatsapp',
      to: to.replace('whatsapp:', ''),
      type: 'image',
      image: { link: imageUrl, caption }
    };
    const res = await axios.post(url, payload, {
      headers: { Authorization: `Bearer ${WHATSAPP_ACCESS_TOKEN}`, 'Content-Type': 'application/json' }
    });
    return res.data;
  } catch (err) {
    console.error('sendWhatsAppImage error', err?.response?.data || err.message);
    throw err;
  }
}

// -------------------- AI parsing --------------------
async function parseDetails(userText) {
  const system = "You are an assistant that extracts name, message and template choice (1/2/3) from user replies. Return a JSON object with keys: name, message, template. Use empty string if not present.";
  const user = "Extract fields from the user text. Return only valid JSON.";
  try {
    const resp = await openai.createChatCompletion({
      model: 'gpt-4o-mini',
      messages: [{ role: 'system', content: system }, { role: 'user', content: user + '\n\n' + userText }],
      temperature: 0
    });
    const raw = resp.data.choices[0].message.content;
    const idx = raw.indexOf('{');
    const jsonText = raw.slice(idx);
    const parsed = JSON.parse(jsonText);
    return { name: parsed.name||'', message: parsed.message||'', template: parsed.template||'' };
  } catch (e) {
    // fallback simple regex
    const nameMatch = userText.match(/Name[:\-]?\s*([^\n]+)/i);
    const msgMatch = userText.match(/Message[:\-]?\s*([^\n]+)/i);
    const tplMatch = userText.match(/Template[:\-]?\s*([123])/i);
    return { name: nameMatch ? nameMatch[1].trim() : '', message: msgMatch ? msgMatch[1].trim() : '', template: tplMatch ? tplMatch[1].trim() : '' };
  }
}

// -------------------- Canva + S3 preview generation --------------------
const TEMPLATE_MAP = {
  'template_1': CANVA_TEMPLATE_1_ID,
  'template_2': CANVA_TEMPLATE_2_ID,
  'template_3': CANVA_TEMPLATE_3_ID
};

async function createPreviewForOrder(order) {
  const templateId = TEMPLATE_MAP[order.templateChoice] || TEMPLATE_MAP['template_1'];
  // create design
  const variables = { NAME: order.name, MESSAGE: order.message };
  const designResp = await canva.createDesignFromTemplate(CANVA_ACCESS_TOKEN, templateId, variables);
  const designId = designResp?.id || designResp?.designId || null;
  if (!designId) throw new Error('No design id from Canva');
  // export preview
  const exportResp = await canva.exportDesignImage(CANVA_ACCESS_TOKEN, designId, { format: 'png', width: 800 });
  let imageBuffer;
  if (exportResp.export_url) {
    const dl = await axios.get(exportResp.export_url, { responseType: 'arraybuffer' });
    imageBuffer = Buffer.from(dl.data);
  } else if (exportResp.download_url) {
    const dl = await axios.get(exportResp.download_url, { responseType: 'arraybuffer' });
    imageBuffer = Buffer.from(dl.data);
  } else if (exportResp.b64) {
    imageBuffer = Buffer.from(exportResp.b64, 'base64');
  } else {
    throw new Error('Unknown exportResp from Canva');
  }
  // watermark + upload
  const { key } = await s3utils.uploadBuffer(imageBuffer, 'previews/');
  const signed = s3utils.getSignedUrl(key, 180);
  order.preview_s3_key = key;
  order.design_id = designId;
  order.status = 'preview_sent';
  await order.save();
  return signed;
}

// -------------------- Conversation flow handlers --------------------
async function startOrder(from) {
  const o = new Order({ whatsapp: from, festival: 'Ganesh Chaturthi', status: 'awaiting_details' });
  await o.save();
  const msg = "Namaste 🙏\nPlease reply with:\nName: \nMessage: \nTemplate: (1,2 or 3)\nExample:\nName: Amit\nMessage: May Lord Ganesha bless you!\nTemplate: 2";
  await sendWhatsAppText(from, msg);
  return o;
}

async function handleIncomingMessage(from, text) {
  // find existing open order
  let order = await Order.findOne({ whatsapp: from, status: { $in: ['awaiting_details','editing','preview_sent','awaiting_approval'] }}).sort({ createdAt: -1 });
  if (!order) {
    order = await startOrder(from);
    // try parse if user already sent details
    if (text && text.length>6) {
      const parsed = await parseDetails(text);
      if (parsed.name || parsed.message || parsed.template) {
        order.name = parsed.name || order.name;
        order.message = parsed.message || order.message;
        order.templateChoice = parsed.template ? `template_${parsed.template}` : order.templateChoice;
        order.status = 'preview_in_progress';
        await order.save();
        await sendWhatsAppText(from, 'Thanks — generating preview now. You will receive it shortly.');
        // generate preview async
        createPreviewForOrder(order).then(async (signedUrl) => {
          await sendWhatsAppImage(from, signedUrl, 'Preview (expires in 3 minutes). Reply "Approve" or "Edit".');
        }).catch(async (err) => {
          console.error('preview error', err);
          await sendWhatsAppText(from, 'Sorry, preview failed. Please try again later.');
        });
        return;
      }
    }
    return;
  }

  // If awaiting details or editing
  if (order.status === 'awaiting_details' || order.status === 'editing') {
    const parsed = await parseDetails(text);
    if (parsed.name) order.name = parsed.name;
    if (parsed.message) order.message = parsed.message;
    if (parsed.template) order.templateChoice = `template_${parsed.template}`;
    order.status = 'preview_in_progress';
    await order.save();
    await sendWhatsAppText(from, 'Thanks — generating preview now. You will receive it shortly.');
    createPreviewForOrder(order).then(async (signedUrl) => {
      await sendWhatsAppImage(from, signedUrl, 'Preview (expires in 3 minutes). Reply "Approve" or "Edit".');
    }).catch(async (err) => {
      console.error('preview error', err);
      await sendWhatsAppText(from, 'Sorry, preview failed. Please try again later.');
    });
    return;
  }

  // If preview_sent awaiting approval
  if (order.status === 'preview_sent' || order.status === 'awaiting_approval') {
    const low = text.trim().toLowerCase();
    if (low.includes('approve') || low.includes('yes')) {
      order.status = 'approved';
      await order.save();
      // create razorpay link
      const payment = await razorpay.paymentLink.create({
        amount: 5000,
        currency: 'INR',
        description: `E-card: ${order.festival}`,
        customer: { name: order.name || 'Customer' },
        notes: { orderId: order._id.toString() }
      });
      order.razorpay_link_id = payment.id;
      order.razorpay_short_url = payment.short_url;
      order.status = 'awaiting_payment';
      await order.save();
      await sendWhatsAppText(from, `Please pay ₹50 here to get your final e-card: ${payment.short_url}`);
      return;
    }
    if (low.includes('edit') || low.includes('change')) {
      order.status = 'editing';
      await order.save();
      await sendWhatsAppText(from, 'Sure — reply with the change e.g. "Name: ..." or "Message: ..." or "Template: 2"');
      return;
    }
    await sendWhatsAppText(from, 'Reply "Approve" to proceed to payment or "Edit" to change the card.');
    return;
  }

  // fallback
  await sendWhatsAppText(from, 'Sorry I did not understand. Reply "Approve" or "Edit" or send Name/Message/Template.');
}

// -------------------- Webhook endpoints --------------------
app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode && token && mode === 'subscribe' && token === WHATSAPP_VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  res.status(403).send('Forbidden');
});

app.post('/webhook', async (req, res) => {
  try {
    const body = req.body;
    if (!body.entry) return res.sendStatus(200);
    for (const entry of body.entry) {
      for (const change of entry.changes || []) {
        const messages = change.value?.messages;
        if (!messages) continue;
        for (const msg of messages) {
          const from = `whatsapp:${msg.from}`;
          const text = msg?.text?.body || '';
          console.log('Received message', from, text);
          await handleIncomingMessage(from, text);
        }
      }
    }
    res.sendStatus(200);
  } catch (err) {
    console.error('Webhook error', err);
    res.sendStatus(500);
  }
});

// Razorpay webhook to confirm payment and generate final
app.post('/api/payment-webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    const sig = req.headers['x-razorpay-signature'];
    const body = req.body;
    const expected = crypto.createHmac('sha256', RAZORPAY_WEBHOOK_SECRET || '').update(body).digest('hex');
    const payload = JSON.parse(body.toString());
    if (payload.event === 'payment_link.paid') {
      const linkId = payload.payload.payment_link.entity.id;
      const notes = payload.payload.payment_link.entity.notes || {};
      let order = await Order.findOne({ razorpay_link_id: linkId }) || (notes.orderId ? await Order.findById(notes.orderId) : null);
      if (!order) return res.json({ ok:true });
      order.status = 'paid';
      await order.save();
      // generate final high-res via Canva and send
      try {
        const exportResp = await canva.exportDesignImage(CANVA_ACCESS_TOKEN, order.design_id, { format:'png', width: 2048 });
        let finalBuf;
        if (exportResp.export_url) {
          const dl = await axios.get(exportResp.export_url, { responseType: 'arraybuffer' });
          finalBuf = Buffer.from(dl.data);
        } else if (exportResp.download_url) {
          const dl = await axios.get(exportResp.download_url, { responseType: 'arraybuffer' });
          finalBuf = Buffer.from(dl.data);
        } else if (exportResp.b64) {
          finalBuf = Buffer.from(exportResp.b64, 'base64');
        }
        const { key } = await s3utils.uploadBuffer(finalBuf, 'finals/');
        order.final_s3_key = key;
        order.status = 'done';
        await order.save();
        const signed = s3utils.getSignedUrl(key, 60*60*24*7);
        await sendWhatsAppText(order.whatsapp, `Thank you! Your final e-card is ready: ${signed}`);
      } catch (err) {
        console.error('final generation error', err);
        await sendWhatsAppText(order.whatsapp, 'Payment received but final generation failed. We will refund or retry.');
      }
    }
    res.json({ ok:true });
  } catch (err) {
    console.error('payment webhook error', err);
    res.status(500).send('error');
  }
});

// Order status endpoint
app.get('/api/order/:id', async (req, res) => {
  const o = await Order.findById(req.params.id);
  if (!o) return res.status(404).json({ error: 'not found' });
  res.json(o);
});

app.get('/', (req, res) => res.send('Festival E-Card Backend running'));
app.listen(PORT, () => console.log(`Server listening on ${PORT}`));
