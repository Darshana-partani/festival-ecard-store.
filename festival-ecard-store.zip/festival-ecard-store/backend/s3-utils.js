/*
s3-utils.js - upload buffers to S3 and generate signed URLs
*/
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION
});
const BUCKET = process.env.S3_BUCKET;

async function uploadBuffer(buffer, keyPrefix = 'previews/', contentType = 'image/png') {
  const key = `${keyPrefix}${Date.now()}_${uuidv4()}.png`;
  await s3.putObject({ Bucket: BUCKET, Key: key, Body: buffer, ContentType: contentType, ACL: 'private' }).promise();
  return { key };
}

function getSignedUrl(key, expiresSec = 300) {
  return s3.getSignedUrl('getObject', { Bucket: BUCKET, Key: key, Expires: expiresSec });
}

module.exports = { uploadBuffer, getSignedUrl };
