// Vercel function - generate ideas via OpenAI
const OpenAI = require('openai');
const dotenv = require('dotenv');
dotenv.config();
const openai = new OpenAI.OpenAIApi(new OpenAI.Configuration({ apiKey: process.env.OPENAI_API_KEY }));

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).send('Method Not Allowed');
  const { festival } = req.body;
  try {
    const prompt = `Give 4 short heartfelt greeting messages for ${festival} festival e-cards in India, each on its own line.`;
    const completion = await openai.createChatCompletion({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: prompt }] });
    const text = completion.data.choices[0].message.content;
    const options = text.split('\n').map(s=>s.trim()).filter(Boolean).slice(0,4);
    res.json({ options });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'ideas failed' });
  }
};
