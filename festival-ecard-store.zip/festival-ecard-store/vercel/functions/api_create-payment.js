// Example Vercel serverless function for creating a Razorpay payment link
const Razorpay = require('razorpay');
const dotenv = require('dotenv');
dotenv.config();

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).send('Method Not Allowed');
  const { festival, name, message, orderId } = req.body;
  const razorpay = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
  try {
    const paymentLink = await razorpay.paymentLink.create({
      amount: 5000,
      currency: 'INR',
      description: `E-card ${festival}`,
      customer: { name: name || 'Customer' },
      notes: { orderId }
    });
    res.json({ paymentUrl: paymentLink.short_url, orderId: paymentLink.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'create payment failed' });
  }
};
